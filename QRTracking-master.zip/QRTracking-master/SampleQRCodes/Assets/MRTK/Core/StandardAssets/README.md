# Mixed Reality Toolkit - Resources

A unique set of critical resources to the Mixed Reality Toolkit's operation.

> Note
> This should contain standard or reusable assets, as they should be catered for within the SDK project's "Standard Assets" Folder