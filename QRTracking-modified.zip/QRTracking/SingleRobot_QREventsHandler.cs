﻿using Microsoft.MixedReality.QR;
using QRTracking;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SingleRobot_QREventsHandler : MonoBehaviour
{
    private bool clearExisting = false;
    public Text debugText;
    public GameObject associatedRobotObj;

    public GameObject QRCode_SR_Face1;
    public GameObject QRCode_SR_Face2;
    public GameObject QRCode_SR_Face3;
    public GameObject QRCode_SR_Face4;
    public GameObject QRCode_SR_Face5;
    public GameObject QRCode_SR_Face6;

    private GameObject[] qrCodesList;
    private Vector3 ARcenterPoint = new Vector3();
    //keep track of QR codes having latest changes to avoid existing/old QR codes that are not aligned with the QR cube anymore
    List<GameObject> latestUpdateQRCodes = new List<GameObject>();
    GameObject latestUpdatedQR = null;
    bool isInitiated = false;
    struct ActionData
    {
        public enum Type
        {
            Added,
            Updated,
            Removed
        };
        public Type type;
        public Microsoft.MixedReality.QR.QRCode qrCode;

        public ActionData(Type type, Microsoft.MixedReality.QR.QRCode qRCode) : this()
        {
            this.type = type;
            qrCode = qRCode;
        }
    }

    private System.Collections.Generic.Queue<ActionData> pendingActions = new Queue<ActionData>();
    // Start is called before the first frame update
    void Start()
    {
        QRCodesManager.Instance.QRCodesTrackingStateChanged += Instance_QRCodesTrackingStateChanged;
        QRCodesManager.Instance.QRCodeAdded += Instance_QRCodeAdded;
        QRCodesManager.Instance.QRCodeUpdated += Instance_QRCodeUpdated;
        QRCodesManager.Instance.QRCodeRemoved += Instance_QRCodeRemoved;

        qrCodesList = new GameObject[6];
        qrCodesList[0] = QRCode_SR_Face1;
        qrCodesList[1] = QRCode_SR_Face2;
        qrCodesList[2] = QRCode_SR_Face3;
        qrCodesList[3] = QRCode_SR_Face4;
        qrCodesList[4] = QRCode_SR_Face5;
        qrCodesList[5] = QRCode_SR_Face6;
        
        ResetQRCodeObjects();
        isInitiated = false;
    }
    void ResetQRCodeObjects()
    {
        QRCode_SR_Face1.SetActive(false);
        QRCode_SR_Face2.SetActive(false);
        QRCode_SR_Face3.SetActive(false);
        QRCode_SR_Face4.SetActive(false);
        QRCode_SR_Face5.SetActive(false);
        QRCode_SR_Face6.SetActive(false);
    }
    int CountAvailableQRCodes()
    {
        int avaiQRCount = 0;
        for (int i = 0; i < qrCodesList.Length; i++)
        {
            GameObject qrCodeObj = qrCodesList[i];
            if (qrCodeObj.GetComponent<SpatialGraphCoordinateController>().IsEnabled)
            {
                avaiQRCount++;
            }
        }
        return avaiQRCount;
    }
    void OnEnable()
    {
        ResetQRCodeObjects();
    }
    void OnApplicationPause()
    {
        foreach (GameObject qrCodeObj in qrCodesList)
        {
            qrCodeObj.SetActive(false);
        }
    }
    private void Instance_QRCodesTrackingStateChanged(object sender, bool status)
    {
        if(!status)
        {
            clearExisting = true;
        }
    }
    
    private void Instance_QRCodeAdded(object sender, QRCodeEventArgs<Microsoft.MixedReality.QR.QRCode> e)
    {
        lock (pendingActions)
        {
            pendingActions.Enqueue(new ActionData(ActionData.Type.Added, e.Data));
        }

    }
    private void Instance_QRCodeUpdated(object sender, QRCodeEventArgs<Microsoft.MixedReality.QR.QRCode> e)
    {
        lock (pendingActions)
        {
            pendingActions.Enqueue(new ActionData(ActionData.Type.Updated, e.Data));
        }
    }

    private void Instance_QRCodeRemoved(object sender, QRCodeEventArgs<Microsoft.MixedReality.QR.QRCode> e)
    {
        lock (pendingActions)
        {
            pendingActions.Enqueue(new ActionData(ActionData.Type.Removed, e.Data));
        }
    }
    // Update is called once per frame
    void Update()
    {
        if(!isInitiated && CountAvailableQRCodes() > 0)
        {
            ResetQRCodeObjects();
            isInitiated = true;
        }
        HandleEvents();
        UpdateARMarkerCenterPoint();
    }
    
    private void HandleEvents()
    {
        string QRCodesInfoStr = "";
        latestUpdateQRCodes = new List<GameObject>();
        while(pendingActions.Count > 0)
        {
            ActionData action = pendingActions.Dequeue();
            QRCode qrCode = action.qrCode;
            GameObject targetQRCodeObj = getQRObjFromQRCodeString(qrCode.Data);
            if (action.type == ActionData.Type.Added)
            {
                QRCodesInfoStr += "Added: " + qrCode.Data + "; ";
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().IsEnabled = true;
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().NeedUpdateLocation = true;
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().Id = qrCode.SpatialGraphNodeId;
                targetQRCodeObj.GetComponent<QRCodeController>().qrCode = qrCode;
                targetQRCodeObj.SetActive(true);
                latestUpdateQRCodes.Add(targetQRCodeObj);
                latestUpdatedQR = targetQRCodeObj;
            }
            else if(action.type == ActionData.Type.Updated)
            {
                QRCodesInfoStr += "Updated: " + qrCode.Data + "; ";
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().IsEnabled = true;
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().NeedUpdateLocation = true;
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().Id = qrCode.SpatialGraphNodeId;
                targetQRCodeObj.GetComponent<QRCodeController>().qrCode = qrCode;
                targetQRCodeObj.SetActive(true);
                latestUpdateQRCodes.Add(targetQRCodeObj);
                latestUpdatedQR = targetQRCodeObj;
            }
            else if(action.type == ActionData.Type.Removed)
            {
                QRCodesInfoStr += "Removed: " + qrCode.Data + "; ";
                targetQRCodeObj.GetComponent<SpatialGraphCoordinateController>().IsEnabled = false;
                targetQRCodeObj.SetActive(false);
            }
        }
    }
    void UpdateARMarkerCenterPoint()
    {
        /*if(CheckQRCodesAligned(out ARcenterPoint))
        {
            Vector3 arMarkerToRobotOrigin = associatedRobotObj.GetComponent<MarkerBasedARController>().CenterMarkerToOrigin();
            Vector3 newRobotPosition = ARcenterPoint - arMarkerToRobotOrigin;
            associatedRobotObj.transform.position = newRobotPosition;
        }*/
        if(latestUpdatedQR != null)
        {
            ARcenterPoint = latestUpdatedQR.GetComponent<QRCodeController>().getAnchorPositionForARObject();
            Vector3 arMarkerToRobotOrigin = associatedRobotObj.GetComponent<MarkerBasedARController>().CenterMarkerToOrigin();
            Vector3 newRobotPosition = ARcenterPoint - arMarkerToRobotOrigin;
            associatedRobotObj.transform.position = newRobotPosition;
        }
    }
    GameObject getQRObjFromQRCodeString(string qrString)
    {
        for(int i=0; i< qrCodesList.Length; i++)
        {
            if(qrCodesList[i].name.CompareTo(qrString)==0)
            {
                return qrCodesList[i];
            }
        }
        return null;
    }
}
