﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if WINDOWS_UWP
using Windows.Perception.Spatial;
#endif

public class WorldOriginController : MonoBehaviour
{
    object accessLock = new object();
#if WINDOWS_UWP
        private SpatialCoordinateSystem originCoordinateSystem = null;
        public SpatialCoordinateSystem GetOriginSpatialCoordinateSystem()
        {
            lock(accessLock)
            {
                return originCoordinateSystem;
            }
        }
#endif

    // Start is called before the first frame update
    void Start()
    {
#if WINDOWS_UWP
            SpatialStationaryFrameOfReference spatialFrameReference = Windows.Perception.Spatial.SpatialLocator.GetDefault().CreateStationaryFrameOfReferenceAtCurrentLocation();
            originCoordinateSystem = spatialFrameReference.CoordinateSystem;
#endif
    }

    // Update is called once per frame
    /*
    void Update()
    {
        
    }
    */
}
