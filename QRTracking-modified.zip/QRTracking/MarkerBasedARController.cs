﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MarkerBasedARController : MonoBehaviour
{
    public GameObject originPoint;
    public GameObject arMarkerPlacePoint;
    public Vector3 CenterMarkerToOrigin()
    {
        return fromARMarkerToOrigin;
    }
    Vector3 fromARMarkerToOrigin = new Vector3();
    // Start is called before the first frame update
    void Start()
    {
        fromARMarkerToOrigin = arMarkerPlacePoint.transform.position - originPoint.transform.position;
    }
    void Awake()
    {
        fromARMarkerToOrigin = arMarkerPlacePoint.transform.position - originPoint.transform.position;
    }

    // Update is called once per frame

    void Update()
    {
        //fromARMarkerToOrigin = arMarkerPlacePoint.transform.position - originPoint.transform.position;
    }
}
