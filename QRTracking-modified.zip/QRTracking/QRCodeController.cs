﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QRCodeController : MonoBehaviour
{
    public GameObject qrCodeArea;
    public GameObject backCenterPoint;
    public Text qrCodeInfoText;
    public Microsoft.MixedReality.QR.QRCode qrCode;
    private Vector3 qrCodeAreaOriginLocalScale;
    private Vector3 wholeQRCodeOriginLocalScale;
    Vector3 ARAnchorPos;
    bool isActive = false;
    public bool IsCurrentlyActive()
    {
        return isActive;
    }
    // Start is called before the first frame update
    void Start()
    {
        qrCodeAreaOriginLocalScale = qrCodeArea.transform.localScale;
        wholeQRCodeOriginLocalScale = gameObject.transform.localScale;
        isActive = false;
        //gameObject.SetActive(false);
    }
    
    void OnEnable()
    {
        isActive = true;
    }
    void OnDisable()
    {
        isActive = false;
    }
    public Vector3 getAnchorPositionForARObject()
    {
        return ARAnchorPos;
    }
    // Update is called once per frame
    void Update()
    {
        UpdatePropertiesDisplay();
    }
    void UpdatePropertiesDisplay()
    {
        if(qrCode != null)
        {
            
            float QRPhysicalSize = qrCode.PhysicalSideLength;
            float sizeChangeRatio = QRPhysicalSize / qrCodeAreaOriginLocalScale.x;
            float wholeQRScale = sizeChangeRatio * wholeQRCodeOriginLocalScale.x;
            //qrCodeInfoText.text = qrCode.Data + System.Environment.NewLine + QRPhysicalSize.ToString();
            gameObject.transform.localScale = new Vector3(wholeQRScale, wholeQRScale, wholeQRScale);
            //qrCodeArea.transform.localScale = new Vector3(physicalSize, physicalSize, qrCodeOriginLocalScale.z);
            //qrCodeArea.transform.localPosition = new Vector3(physicalSize / 2.0f, physicalSize / 2.0f, 0.0f);
            ARAnchorPos = backCenterPoint.transform.position;
        }
    }
}
